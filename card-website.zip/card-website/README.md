# From the Heart Cards — Setup Guide

Your complete handwritten card ordering website with Stripe payments.

---

## What's in this folder

```
card-website/
├── server.js          ← Backend (Node.js). Handles payments & emails.
├── package.json       ← Project dependencies
├── .env.example       ← Copy this to .env and fill in your keys
├── .gitignore         ← Keeps secrets out of GitHub
└── public/
    ├── index.html     ← Your website (order form)
    └── success.html   ← Page shown after successful payment
```

---

## Step 1 — Install Node.js

Download and install Node.js from https://nodejs.org (choose the "LTS" version).

---

## Step 2 — Install the project dependencies

Open a terminal in this folder and run:

```bash
npm install
```

---

## Step 3 — Set up Stripe

1. Create a free account at https://stripe.com
2. Go to **Developers → API Keys**
3. Copy your **Secret key** (starts with `sk_test_...`)
4. You'll also need a **Webhook Secret** — see Step 5 for that

---

## Step 4 — Set up Gmail for email notifications

You need a Gmail App Password (this is NOT your normal Gmail password):

1. Go to https://myaccount.google.com/security
2. Make sure **2-Step Verification** is turned on
3. Go to https://myaccount.google.com/apppasswords
4. Create a new app password — name it "Card Website"
5. Copy the 16-character password it gives you

---

## Step 5 — Create your .env file

Copy the example file:

```bash
cp .env.example .env
```

Then open `.env` and fill in your values:

```
STRIPE_SECRET_KEY=sk_test_your_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_secret_here   ← Get this in the next step
EMAIL_USER=youremail@gmail.com
EMAIL_PASS=xxxx xxxx xxxx xxxx                 ← Your Gmail App Password
OWNER_EMAIL=youremail@gmail.com
SITE_URL=http://localhost:3000
PORT=3000
```

---

## Step 6 — Set up your Stripe webhook (for emails to send)

Stripe needs to notify your server when a payment succeeds. Here's how:

### While testing locally:

1. Download the Stripe CLI: https://stripe.com/docs/stripe-cli
2. Run this in a terminal:
   ```bash
   stripe listen --forward-to localhost:3000/webhook
   ```
3. It will print a webhook secret like `whsec_abc123...` — copy that into your `.env` as `STRIPE_WEBHOOK_SECRET`

### When your site is live:

1. Go to **Stripe Dashboard → Developers → Webhooks**
2. Click **Add endpoint**
3. Enter your URL: `https://yourdomain.com/webhook`
4. Select the event: `checkout.session.completed`
5. Copy the **Signing secret** into your `.env`

---

## Step 7 — Run the server

```bash
node server.js
```

You should see:
```
✦ From the Heart Cards server running at http://localhost:3000
```

Open http://localhost:3000 in your browser — your site is live locally!

---

## Step 8 — Test a payment

Use Stripe's test card details:
- **Card number:** `4242 4242 4242 4242`
- **Expiry:** Any future date (e.g. `12/34`)
- **CVC:** Any 3 digits (e.g. `123`)
- **ZIP:** Any 5 digits

This will go through the full checkout flow without charging a real card.
Check your email — you should receive both the customer confirmation and your order notification.

---

## Step 9 — Put it live on the internet

### Deploy to Railway (easiest, ~$5/month):

1. Create an account at https://railway.app
2. Click **New Project → Deploy from GitHub repo**
3. Push your code to GitHub first (make sure `.env` is in `.gitignore`!)
4. In Railway, go to your project's **Variables** tab and add all your `.env` values
5. Railway will give you a URL like `https://your-app.railway.app`
6. Update `SITE_URL` in your Railway variables to that URL
7. Update your Stripe webhook endpoint URL to match

### Connect your custom domain:

1. Buy a domain from Namecheap or Google Domains (~$12/year)
2. In Railway, go to **Settings → Networking → Custom Domain**
3. Follow their instructions to point your domain at Railway

---

## Going live checklist

Before switching from test mode to real payments:

- [ ] Replace `sk_test_...` with your live Stripe secret key (`sk_live_...`)
- [ ] Update your Stripe webhook to use your live domain
- [ ] Update `SITE_URL` to your real domain
- [ ] Do one final test order with a real card (then refund it from Stripe dashboard)

---

## Questions?

If anything isn't working, the most common issues are:
- `.env` file not saved properly — double-check every value has no extra spaces
- Gmail App Password — make sure 2FA is on and you're using the app password, not your real password
- Stripe webhook — make sure the `stripe listen` command is running while testing locally
