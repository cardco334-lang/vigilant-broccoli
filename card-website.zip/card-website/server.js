// ============================================================
//  From the Heart Cards — Backend Server
//  Node.js + Express + Stripe + Nodemailer
// ============================================================
//
//  SETUP INSTRUCTIONS:
//  1. Run: npm install
//  2. Copy .env.example to .env and fill in your keys
//  3. Run: node server.js
//  4. Your server runs at http://localhost:3000
// ============================================================

require("dotenv").config();
const express = require("express");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const nodemailer = require("nodemailer");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const CARD_PRICE_CENTS = 1500; // $15.00

// ── Middleware ───────────────────────────────────────────────
// Stripe webhooks need raw body, so this must come first
app.use("/webhook", express.raw({ type: "application/json" }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ── Email transporter ────────────────────────────────────────
// Uses Gmail by default. See .env.example for other options.
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS, // Use a Gmail App Password, not your real password
  },
});

// ── Helper: send emails ──────────────────────────────────────
async function sendEmails(orderData) {
  const {
    occasion,
    recipientName,
    message,
    senderName,
    specialInstructions,
    streetAddress,
    city,
    state,
    zip,
    customerName,
    customerEmail,
  } = orderData;

  const fullAddress = [streetAddress, city, state, zip].filter(Boolean).join(", ");

  // Email to YOU (the business owner)
  await transporter.sendMail({
    from: `"From the Heart Cards" <${process.env.EMAIL_USER}>`,
    to: process.env.OWNER_EMAIL,
    subject: `New Card Order — ${occasion} for ${recipientName}`,
    html: `
      <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; color: #1C1410;">
        <h2 style="color: #C4876A; font-style: italic;">New order received!</h2>
        <hr style="border: none; border-top: 1px solid #eee;" />

        <h3>Card Details</h3>
        <table style="width:100%; font-size:15px; line-height:1.7;">
          <tr><td style="color:#8A7B72; width:160px;">Occasion</td><td><strong>${occasion}</strong></td></tr>
          <tr><td style="color:#8A7B72;">To</td><td>${recipientName}</td></tr>
          <tr><td style="color:#8A7B72;">Signed</td><td>${senderName || "(not specified)"}</td></tr>
          <tr><td style="color:#8A7B72; vertical-align:top;">Message</td><td style="font-style:italic;">"${message}"</td></tr>
          <tr><td style="color:#8A7B72; vertical-align:top;">Special notes</td><td>${specialInstructions || "None"}</td></tr>
        </table>

        <h3 style="margin-top:1.5rem;">Ship To</h3>
        <p style="font-size:15px;">${fullAddress}</p>

        <h3 style="margin-top:1.5rem;">Customer</h3>
        <table style="width:100%; font-size:15px; line-height:1.7;">
          <tr><td style="color:#8A7B72; width:160px;">Name</td><td>${customerName}</td></tr>
          <tr><td style="color:#8A7B72;">Email</td><td>${customerEmail}</td></tr>
        </table>

        <hr style="border: none; border-top: 1px solid #eee; margin-top:1.5rem;" />
        <p style="font-size:13px; color:#8A7B72;">Payment of $15.00 collected via Stripe.</p>
      </div>
    `,
  });

  // Confirmation email to CUSTOMER
  await transporter.sendMail({
    from: `"From the Heart Cards" <${process.env.EMAIL_USER}>`,
    to: customerEmail,
    subject: `Your order is confirmed 💌`,
    html: `
      <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; color: #1C1410;">
        <h2 style="color: #C4876A; font-style: italic;">Your card is on its way!</h2>
        <p>Hi ${customerName},</p>
        <p>Thank you so much for your order. We'll handwrite your <strong>${occasion}</strong> card for <strong>${recipientName}</strong> with care and have it in the mail within 3–5 business days.</p>

        <div style="background:#FAF7F2; border-left: 3px solid #C4876A; padding: 1rem 1.25rem; margin: 1.5rem 0; border-radius: 4px;">
          <p style="margin:0; font-style:italic; font-size:15px;">"${message}"</p>
          ${senderName ? `<p style="margin:0.5rem 0 0; font-size:13px; color:#8A7B72;">— ${senderName}</p>` : ""}
        </div>

        <p>Being mailed to: <strong>${fullAddress}</strong></p>

        <p>Questions? Just reply to this email.</p>
        <p style="font-style:italic; color:#C4876A;">— From the Heart Cards</p>
      </div>
    `,
  });
}

// ── Route: Create Stripe Checkout Session ────────────────────
// This creates a hosted Stripe checkout page for $15.
// The order data is stored in metadata so we can retrieve it after payment.
app.post("/create-checkout-session", async (req, res) => {
  try {
    const {
      occasion,
      recipientName,
      message,
      senderName,
      specialInstructions,
      streetAddress,
      city,
      state,
      zip,
      customerName,
      customerEmail,
    } = req.body;

    // Basic validation
    if (!occasion || !recipientName || !message || !streetAddress || !city || !state || !zip || !customerName || !customerEmail) {
      return res.status(400).json({ error: "Missing required order fields." });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      customer_email: customerEmail,
      line_items: [
        {
          price_data: {
            currency: "usd",
            unit_amount: CARD_PRICE_CENTS,
            product_data: {
              name: `Handwritten ${occasion} Card`,
              description: `For ${recipientName} · Mailed to ${city}, ${state}`,
            },
          },
          quantity: 1,
        },
      ],
      // Store order details in metadata so the webhook can retrieve them
      metadata: {
        occasion,
        recipientName,
        message: message.substring(0, 500), // Stripe metadata has a 500 char limit per field
        senderName: senderName || "",
        specialInstructions: specialInstructions || "",
        streetAddress,
        city,
        state,
        zip,
        customerName,
        customerEmail,
      },
      success_url: `${process.env.SITE_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.SITE_URL}/#order`,
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error("Stripe session error:", err.message);
    res.status(500).json({ error: "Could not create checkout session." });
  }
});

// ── Route: Order Details (for success page) ──────────────────
// The success page calls this to display what was ordered.
app.get("/order-details", async (req, res) => {
  const { session_id } = req.query;
  if (!session_id) return res.status(400).json({ error: "Missing session_id" });

  try {
    const session = await stripe.checkout.sessions.retrieve(session_id);
    if (session.payment_status !== "paid") {
      return res.status(400).json({ error: "Payment not completed" });
    }
    res.json(session.metadata);
  } catch (err) {
    res.status(500).json({ error: "Could not retrieve order" });
  }
});

// ── Route: Stripe Webhook ────────────────────────────────────
// Stripe calls this automatically after a successful payment.
// This is where we send the order emails.
app.post("/webhook", async (req, res) => {
  const sig = req.headers["stripe-signature"];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature error:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;

    // Only send emails if payment was actually collected
    if (session.payment_status === "paid") {
      try {
        await sendEmails(session.metadata);
        console.log(`Order emails sent for session ${session.id}`);
      } catch (err) {
        console.error("Email send error:", err.message);
        // Don't return 500 — Stripe will retry webhooks on failure
      }
    }
  }

  res.json({ received: true });
});

// ── Start server ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✦ From the Heart Cards server running at http://localhost:${PORT}\n`);
});
